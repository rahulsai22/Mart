const supertest = require('supertest')
const app = require('../app')

describe("testing user api", () => {
    it("signup user", async () => {
        const res = await supertest(app).post('/api/users/signup').send({
            name: "smit",
            email: "smit32@gmail.com",
            mobile: "9876543210",
            city: "surat",
            password: "smit1234",
        })

        expect(res.status).toBe(201)
    })


    it('test get garbage api', async () => {
        const res = await supertest(app).get('/api/users/getgarbage');
        expect(res.status).toBe(200)
    })

    it("tests the login routes", async () => {
        const response = await supertest(app).post('/api/users/login').send({
            email: "smit54@gmail.com",
            password: 'smit1234'
        })
        expect(response.status).toBe(200)
    })

    it("test should not login unauthorized user", async () => {
        const response = await supertest(app).post('/api/users/login').send({
            email: "smit178@gmail.com",
            password: 'smit11111'
        })
        expect(response.status).toBe(404)
    })

    it("test check user api", async () => {
        const res = await supertest(app).post('/api/users/checkuser').send({
            email: "smit54@gmail.com"
        })
        expect(res.status).toBe(200)
    })

    it("test check user failed api", async () => {
        const res = await supertest(app).post('/api/users/checkuser').send({
            email: "smit123@gmail.com"
        })
        expect(res.status).toBe(400)
    })

})