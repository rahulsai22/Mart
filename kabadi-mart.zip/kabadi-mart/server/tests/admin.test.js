const request = require('supertest')
const app = require('../app')
const mongoose = require('mongoose')

describe("Testing the admin Api", () => {
    const gcid = new mongoose.Types.ObjectId
    it("add garbage collector", async () => {
        const response = await request(app).post('/api/admin/registergc').send({
            _id: gcid,
            name: 'smit',
            email: 'desaismit25@gmail.com',
            mobile: '5412658945',
            city: "surat123",
            address: "sda das dsdas dasda sdasd asdas dasdas dasda sdasd asdas assdas dass",
            password: '12345678'
        });
        expect(response.status).toBe(201);
    })

    it("get garbage collectors", async () => {
        const response = await request(app).get('/api/admin/getgc')
        expect(response.status).toBe(200)

    })

    it("cancel garbage collector", async () => {
        const response = await request(app).post('/api/admin/cancelgc').send({ id: gcid });
        expect(response.status).toBe(200)
    })

    it("get admin wallet transaction", async () => {
        const response = await request(app).get('/api/admin/gettransaction')
        expect(response.status).toBe(200)
    })

    it("get orders", async () => {
        const response = await request(app).post('/api/admin/getorders').send({
            city: "Surat"
        })
        expect(response.status).toBe(200)
    })

})