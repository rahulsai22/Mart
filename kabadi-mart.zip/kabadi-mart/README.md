# Scrapdeal
Consider following Steps for run the Project.
1. cd server
2. npm run dev
